@echo off
cd /d %~dp0
echo Starting your coach (ADK agent)...
start "Coach - keep open" cmd /k python -m google.adk.cli web --allow_origins https://moonstudio-dev.github.io --allow_origins http://localhost:5500
timeout /t 10
echo.
echo Opening a public link to your coach. Copy the https://....trycloudflare.com address below.
cloudflared tunnel --url http://localhost:8000
