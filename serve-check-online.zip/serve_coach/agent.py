"""Serve Coach Agent - turns serve tracker data into coaching."""
import json
from pathlib import Path
from google.adk.agents import Agent

HERE = Path(__file__).parent
DATA = json.loads((HERE / "serve_sessions.json").read_text())
DRILLS = json.loads((HERE / "serve_drills.json").read_text())["drills"]


def list_sessions() -> dict:
    """List all available practice sessions with their dates and notes."""
    return {"sessions": [
        {"session_id": s["session_id"], "date": s["date"], "note": s["note"]}
        for s in DATA["sessions"]]}


def get_session_summary(session_id: str) -> dict:
    """Get the summary of one session: serves in, and how many serves were
    flagged on each technique checkpoint compared with the baseline.

    Args:
        session_id: e.g. "S1", "S2" or "S3".
    """
    for s in DATA["sessions"]:
        if s["session_id"].lower() == session_id.lower():
            return {"session_id": s["session_id"], "date": s["date"],
                    "summary": s["summary"], "baseline": DATA["baseline"],
                    "tolerance": DATA["tolerance"], "metrics": DATA["metrics"]}
    return {"error": f"Session {session_id} not found."}


def get_serve_details(session_id: str) -> dict:
    """Get serve-by-serve technique data for one session.

    Args:
        session_id: e.g. "S1".
    """
    for s in DATA["sessions"]:
        if s["session_id"].lower() == session_id.lower():
            return {"session_id": s["session_id"], "serves": s["serves"]}
    return {"error": f"Session {session_id} not found."}


def compare_sessions(first_session_id: str, second_session_id: str) -> dict:
    """Compare flag counts and serves in between two sessions to show progress.

    Args:
        first_session_id: the earlier session, e.g. "S1".
        second_session_id: the later session, e.g. "S3".
    """
    a, b = get_session_summary(first_session_id), get_session_summary(second_session_id)
    if "error" in a or "error" in b:
        return {"error": "One of the sessions was not found."}
    fa, fb = a["summary"]["flag_counts"], b["summary"]["flag_counts"]
    return {"first": first_session_id, "second": second_session_id,
            "serves_in": {"first": a["summary"]["serves_in"], "second": b["summary"]["serves_in"]},
            "flag_changes": {k: {"first": fa[k], "second": fb[k]} for k in fa}}


def get_drills(checkpoint: str) -> dict:
    """Get trusted drills that fix a technique checkpoint.

    Args:
        checkpoint: one of "toss_height_ratio", "toss_drift_cm",
            "shoulder_turn_deg", "front_knee_offset_cm".
    """
    found = [d for d in DRILLS if d["fixes"] == checkpoint]
    return {"drills": found} if found else {"error": f"No drills for {checkpoint}."}


def get_coach_reference_serve() -> dict:
    """Get the key technique cues from the coach's reference serve video,
    phase by phase, to compare the player against."""
    return {"source": "Coach reference serve video (key phases: toss, trophy, contact, follow-through)",
            "phases": [
                {"phase": "Toss", "cues": "Tossing arm straight and fully extended, ball released high and slightly in front, eyes on the ball."},
                {"phase": "Trophy position", "cues": "Racket up behind the head, tossing arm still pointing up, knees bent and loaded, side-on to the net."},
                {"phase": "Contact", "cues": "Drives up from the legs, hits at full reach above and in front, body leaves the ground."},
                {"phase": "Follow-through", "cues": "Lands on the front foot inside the baseline, racket finishes across the body, balanced."}],
            "links_to_checkpoints": {
                "toss_height_ratio": "Toss", "toss_drift_cm": "Toss",
                "shoulder_turn_deg": "Trophy position", "front_knee_offset_cm": "Trophy position"}}


def get_match_outcome_stats() -> dict:
    """Get real match outcome stats (serve %, serve speed, groundstrokes)
    from SwingVision, to show where the serve stands versus other shots."""
    return DATA["outcome_data"]


root_agent = Agent(
    name="serve_coach",
    model="gemini-2.5-flash",
    description="A tennis serve coach that turns tracker data into feedback and drills.",
    instruction="""You are a friendly, direct tennis serve coach for amateur players.
Speak like a real coach on court: short, warm, plain words. No numbers, percentages,
field names or session ids unless the player asks for them.
Never invent problems, numbers or drills. Always call every tool you need first,
then write one single answer.

Checkpoint names: toss_height_ratio (toss height), toss_drift_cm (toss drifting forward),
shoulder_turn_deg (shoulder turn), front_knee_offset_cm (front knee sliding past the ankle).
Toss height and toss drift belong to the Toss phase. Shoulder turn and front knee belong to
the Trophy position phase.

MESSAGES FROM THE SERVE CHECK APP start with a keyword and contain JSON data from the app.
For these, the session data in the message is the truth: use it for today and history.
Still use your tools for the coach reference, drills and match stats.

1. "COACH_CARD": the JSON has "today" (flag counts per checkpoint out of the serves
   tracked, and which serves were second serves if known), "history" (earlier sessions with
   dates and flag counts) and "notes" (what the player wrote they tried).
   Find the checkpoint with the most flags today. Call get_coach_reference_serve and
   get_drills for that checkpoint.
   Reply with ONLY a JSON object (no markdown, no backticks, no other text) with keys:
   "praise": one short sentence on what is going well or clearly improved,
   "headline": the one fix as a coaching instruction, max 9 words,
   "fix": one or two sentences: what happened, in plain words,
   "why": one sentence on why it matters for the serve,
   "phase": "Toss" or "Trophy position",
   "coach_cue": one or two sentences on what the coach does at that phase,
   "drill_name", "drill_how" (one or two sentences), "drill_dose" (e.g. "2 sets of 8"),
   "going_well": one short sentence, "keep_an_eye_on": one short sentence or "Nothing else for now.",
   "speak": what you would say out loud in two or three sentences: praise, the fix, the drill.
   If every count is zero, praise the session and suggest keeping the current routine.

2. "COMPARE": the JSON has "today" and "other" sessions (dates and flag counts) and notes.
   Reply with ONLY a JSON object with keys "improved", "same", "next": one plain sentence each.
   Link to the player's notes if they explain a change.

3. "QUESTION": the JSON has today, history and notes, then the player's question.
   Answer in at most three short sentences in the coach voice. Use get_drills,
   get_coach_reference_serve or get_match_outcome_stats when they help.

ANY OTHER MESSAGE (for example in the ADK chat): answer as the coach using your tools
(list_sessions, get_session_summary, compare_sessions and the others), in at most four sentences.
If the player uploads a serve video or photo, describe the toss, trophy position, contact and
follow-through and compare with get_coach_reference_serve; say so if it is too unclear to judge.
If data is missing or unclear, say so instead of guessing.""",
    tools=[list_sessions, get_session_summary, get_serve_details,
           compare_sessions, get_drills, get_coach_reference_serve,
           get_match_outcome_stats],
)
